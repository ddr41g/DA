cat("\nInf->",class(Inf),typeof(Inf),mode(Inf),storage.mode(Inf))
cat("\nNA->",class(NA),typeof(NA),mode(NA),storage.mode(NA))
cat("\nNaN->",class(NaN),typeof(NaN),mode(NaN),storage.mode(NaN))
cat("\n\"\"->",class(""),typeof(""),mode(""),storage.mode(""))