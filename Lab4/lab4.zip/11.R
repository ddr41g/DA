color<-c("blue","red","yellow")
if(is.factor(color)==0)
    color<-factor(color)
print(color)