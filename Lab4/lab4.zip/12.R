a<-c("a","b","c","d","a","e","b","h","c","f")
a<-factor(a)
print(a)