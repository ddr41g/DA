pets <- factor(sample( c("dog", "cat","hamster","goldfish"), 10000, replace = TRUE))
#print(pets)
summary(pets)
