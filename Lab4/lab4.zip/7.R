s <- readline("Enter String: ")
substr(s,1,5) <- "V-Day"
print(s)