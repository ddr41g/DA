s<- "  Double  Space  Example  "
s<-str_squish(s)
print(s)